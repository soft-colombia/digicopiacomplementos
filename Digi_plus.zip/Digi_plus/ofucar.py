import os
os.system('pyminifier --obfuscate Digi.py')